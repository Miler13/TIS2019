<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NumeroSesion extends Model
{
    protected $table = 'num_sesion';
    protected $primaryKey = 'num_sesion';
    public $timestamps = false;
}
